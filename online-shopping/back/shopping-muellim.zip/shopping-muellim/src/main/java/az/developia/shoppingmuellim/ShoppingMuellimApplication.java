package az.developia.shoppingmuellim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShoppingMuellimApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShoppingMuellimApplication.class, args);
	}

}
